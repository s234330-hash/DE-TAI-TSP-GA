# TSP Genetic Algorithm

## Cách chạy

pip install -r requirements.txt
python ga_tsp.py
